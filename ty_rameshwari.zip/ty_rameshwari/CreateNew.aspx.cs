﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
using System.Configuration;

public partial class CreateNew : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            string CS = ConfigurationManager.ConnectionStrings["Ruchi"].ConnectionString;
            using (OleDbConnection con = new OleDbConnection(CS))
            {
                OleDbCommand cmd = new OleDbCommand("Select * from event_category", con);
                con.Open();
                OleDbDataReader rdr = cmd.ExecuteReader();
                ddl_cat.DataSource = rdr;
                ddl_cat.DataValueField = "cat_id";
                ddl_cat.DataTextField = "cat_name";
                ddl_cat.DataBind();
                ListItem liDefault = new ListItem("Select Category Type", "-1");
                ddl_cat.Items.Insert(0, liDefault);
            }
        }         
    }
    protected void btn_sub_Click(object sender, EventArgs e)
    {
        string CS = ConfigurationManager.ConnectionStrings["Ruchi"].ConnectionString;
        using (OleDbConnection con = new OleDbConnection(CS))
        {
            OleDbCommand cmd = new OleDbCommand("insert into create_new (Event_Name,Event_Date,Event_Description,Event_Category) values ('" + txtbox_name.Text + "','" + txtEventDate.Text + "','" + txtbox_descrip.Text + "','" + ddl_cat.SelectedItem.Text + "')", con);
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds, "create_new");
            lblMsg.Text = "successfully inserted!";
            lblMsg.ForeColor = System.Drawing.Color.Green;
        }
    }
}