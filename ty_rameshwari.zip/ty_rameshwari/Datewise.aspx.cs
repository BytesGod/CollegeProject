﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
using System.Configuration;

public partial class Datewise : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    
    }
    protected void btn_datewise_Click(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();
        string CS = ConfigurationManager.ConnectionStrings["Ruchi"].ConnectionString;
        using (OleDbConnection con = new OleDbConnection(CS))
        {
            con.Open();
            OleDbDataAdapter da = new OleDbDataAdapter("select * from create_new where Event_Date='" + txtDatewise.Text + "'", con);
            da.Fill(dt);
        }
        if (dt.Rows.Count > 0)
        {
            gvDate.DataSource = dt;
            gvDate.DataBind();
        }
        else
        {
            dt.Rows.Add(dt.NewRow());
            gvDate.DataSource = dt;
            gvDate.DataBind();
            gvDate.Rows[0].Cells.Clear();
            gvDate.Rows[0].Cells.Add(new TableCell());
            gvDate.Rows[0].Cells[0].ColumnSpan = dt.Columns.Count;
            gvDate.Rows[0].Cells[0].Text = "No Data Found ..!";
            gvDate.Rows[0].Cells[0].HorizontalAlign = HorizontalAlign.Center;
        }
        
    }
    
}