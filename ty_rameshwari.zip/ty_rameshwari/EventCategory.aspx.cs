﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
using System.Configuration;

public partial class EventCategory : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_add_Click(object sender, EventArgs e)
    {
        string CS = ConfigurationManager.ConnectionStrings["Ruchi"].ConnectionString;
        using (OleDbConnection con = new OleDbConnection(CS))
        {
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandText = "insert into event_category (cat_id ,cat_name) values (" + txtbox_cid.Text + ",'" + txtbox_ename.Text + "')";
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds, "event_category");
            lbl_errmsg.Text = "Add Successfully";
            lbl_errmsg.ForeColor = System.Drawing.Color.Green;          
        }
    }
    protected void lbl_update_Click(object sender, EventArgs e)
    {
        string CS = ConfigurationManager.ConnectionStrings["Ruchi"].ConnectionString;
        using (OleDbConnection con = new OleDbConnection(CS))
        {
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandText = "update event_category set cat_name='" + txtbox_ename.Text + "' where cat_id=" + txtbox_cid.Text + "";
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds, "event_category");
            lbl_errmsg.Text = "Update Successfully";
            lbl_errmsg.ForeColor = System.Drawing.Color.Green;
            
        }
    }
    protected void lbl_delete_Click(object sender, EventArgs e)
    {
        string CS = ConfigurationManager.ConnectionStrings["Ruchi"].ConnectionString;
        using (OleDbConnection con = new OleDbConnection(CS))
        {
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandText = "delete from event_category where cat_id=" + txtbox_cid.Text + " and cat_name='" + txtbox_ename.Text + "'";
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds, "event_catagory");
            lbl_errmsg.Text = "Deleted Successfully";
            lbl_errmsg.ForeColor = System.Drawing.Color.Green;
        }
    }
}