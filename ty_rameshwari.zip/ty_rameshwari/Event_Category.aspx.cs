﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

public partial class Event_Category : System.Web.UI.Page
{
    OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=G:\ty_rameshwari\login.accdb");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_add_Click(object sender, EventArgs e)
    {
        OleDbCommand cmd = con.CreateCommand();
        cmd.CommandText = "insert into event_category (cat_id,cat_name) values ("+txtbox_id.Text+",'"+txtbox_name.Text+"')";
        OleDbDataAdapter da = new OleDbDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds,"event_category");
        con.Close();
    }
    protected void btn_update_Click(object sender, EventArgs e)
    {
        OleDbCommand cmd = con.CreateCommand();
        cmd.CommandText = "update table event_category set cat_name='"+txtbox_name.Text+"' where cat_id="+txtbox_id.Text+"";
        OleDbDataAdapter da = new OleDbDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds, "event_category");
        con.Close();
    }
    protected void btn_delete_Click(object sender, EventArgs e)
    {
        OleDbCommand cmd = con.CreateCommand();
        cmd.CommandText = "delete * from event_category where cat_id="+txtbox_id.Text+" and cat_name='"+txtbox_name.Text+"'";
        OleDbDataAdapter da = new OleDbDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds, "event_catagory");
        Response.Write("deleted!");
        con.Close();
    }
}