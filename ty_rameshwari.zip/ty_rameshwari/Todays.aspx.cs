﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;
using System.Configuration;

public partial class Todays : System.Web.UI.Page
{
   
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_show_Click(object sender, EventArgs e)
    {
        DateTime dat = DateTime.Today;
         string CS = ConfigurationManager.ConnectionStrings["Ruchi"].ConnectionString;
         using (OleDbConnection con = new OleDbConnection(CS))
         {
             con.Open();
             OleDbCommand cmd = new OleDbCommand("select * from create_new where Event_Date =@eventDate",con);
             OleDbParameter event_date = cmd.Parameters.Add("@eventDate", OleDbType.Date);
            
             OleDbDataReader dr = cmd.ExecuteReader();
             gd_today.DataSource = dr;
             gd_today.DataBind();
             con.Dispose();


             

         }
    }
}