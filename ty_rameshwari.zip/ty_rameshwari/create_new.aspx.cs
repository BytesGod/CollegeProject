﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

public partial class create_new : System.Web.UI.Page
{
    OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=G:\ty_rameshwari\login.accdb");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_generate_Click(object sender, EventArgs e)
    {
        con.Open();
        OleDbCommand cmd = con.CreateCommand();
        cmd.CommandText = "insert into create_new (Event_Name,Event_Date,Event_Description,[Event_Category]) values ('"+txtbox_eventname.Text+"','"+cal_eventdate.SelectedDate+"','"+txtbox_des.Text+"','"+ddl_eventcat.Text+"')";
        OleDbDataAdapter da = new OleDbDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds,"create_new");
        con.Close();


    }
}