﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
using System.Configuration;

public partial class login : System.Web.UI.Page
{
    
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_submit_Click(object sender, EventArgs e)
    {
         string CS = ConfigurationManager.ConnectionStrings["Ruchi"].ConnectionString;
         using (OleDbConnection con = new OleDbConnection(CS))
         {
             OleDbCommand cmd = con.CreateCommand();
             cmd.CommandText = "select * from login where USER_NAME=@username and PASSWORD=@password";
             cmd.Parameters.AddWithValue("@username", txtbox_user.Text);
             cmd.Parameters.AddWithValue("@password", txtbox_pswd.Text);
             OleDbDataAdapter da = new OleDbDataAdapter(cmd);
             DataTable dt = new DataTable();
             da.Fill(dt);
             con.Open();
             int i = cmd.ExecuteNonQuery();
             if (dt.Rows.Count > 0)
             {
                 Response.Redirect("~/index.aspx");
             }
             else
             {
                 lblerr.Text = "Your username and word is incorrect";
                 lblerr.ForeColor = System.Drawing.Color.Red;

             }
   
         }
    }
}