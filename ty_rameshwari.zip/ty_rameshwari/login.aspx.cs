﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

public partial class login : System.Web.UI.Page
{
    OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=G:\ty_rameshwari\login.accdb");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_submit_Click(object sender, EventArgs e)
    {
        con.Open();
        OleDbCommand cmd = con.CreateCommand();
        cmd.CommandText = "select count (*) from login where USER_NAME='" + txtbox_user.Text + "' and PASSWORD=" + txtbox_pswd.Text + "";
        int cnt = Convert.ToInt32(cmd.ExecuteScalar());
        if (cnt > 0)
        {
            Response.Write("LOGIN SUCCESSFULL!");
            Response.Redirect("dashboard.aspx");
        }
        else
        {
            Response.Write("INVALID USER_NAME OR PASSWORD!");
        }
        con.Close();
    }
}